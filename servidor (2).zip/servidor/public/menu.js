

function draw_Menu() {
  // Cria um array para armazenar os botões
let botoes = [];
  class Button {
    constructor(centroX, centroY, largura, altura, corBt, corBordaBt, tamTexto, corTexto, conteudo) {
      this.centroX = centroX;
      this.centroY = centroY;
      this.largura = largura;
      this.altura = altura;
      this.corBt = corBt;
      this.corBordaBt = corBordaBt;
      this.tamTexto = tamTexto;
      this.corTexto = corTexto;
      this.conteudo = conteudo;
    }

    // Método para desenhar o botão
    draw_Button() {
      push();
      rectMode(CENTER);
      fill(this.corBt);
      stroke(this.corBordaBt);
      rect(this.centroX, this.centroY, this.largura, this.altura, 20);
      textAlign(CENTER, CENTER);
      textSize(this.tamTexto);
      fill(this.corTexto);
      text(this.conteudo, this.centroX, this.centroY);
      pop();
    }

    // Método para verificar se o botão foi clicado
    isClicked() {
      return mouseX > this.centroX - this.largura / 2 &&
        mouseX < this.centroX + this.largura / 2 &&
        mouseY > this.centroY - this.altura / 2 &&
        mouseY < this.centroY + this.altura / 2;
    }
  }

  // Calcula o centro vertical da tela
  let centroVertical = height / 2;

  // Cria os botões e os adiciona ao array
  let botao1 = new Button(width * 0.5 - 100, centroVertical - 100, 150, 100, "#f5dd67", "#ebeae6", 20, 0, "Jogar");
  let botao2 = new Button(width * 0.5 + 100, centroVertical - 100, 150, 100, "#f5dd67", "#ebeae6", 20, 0, "Deck");
  let botao3 = new Button(width * 0.5 - 100, centroVertical + 100, 150, 100, "#f5dd67", "#ebeae6", 20, 0, "Perfil");
  let botao4 = new Button(width * 0.5 + 100, centroVertical + 100, 150, 100, "#f5dd67", "#ebeae6", 20, 0, "Loja");

  botoes.push(botao1, botao2, botao3, botao4);

  // Desenha os botões e verifica se foram clicados
  for (let m = 0; m < botoes.length; m++) {
    botoes[m].draw_Button();

    if (botoes[m].isClicked()) {
      // Lógica a ser executada quando o botão é clicado
      console.log("Botão " + (m + 1) + " clicado!");

      // Adicione a lógica específica para cada cena do jogo aqui
      if (m === 0) {
        // Lógica para a cena do Menu
        console.log("Ir para a cena do Menu");
        // Adicione a lógica específica para a cena do Menu aqui
      } else if (m === 1) {
        // Lógica para a cena do Deck
        console.log("Ir para a cena do Deck");
        // Adicione a lógica específica para a cena do Deck aqui
      } else if (m === 2) {
        // Lógica para a cena do Perfil
        console.log("Ir para a cena do Perfil");
        scene=3;
        // Adicione a lógica específica para a cena do Perfil aqui
      } else if (m === 3) {
        // Lógica para a cena do Logout
        console.log("Ir para a cena do Logout");
        // Adicione a lógica específica para a cena do Logout aqui
      }
    }
  }
}